# Restaurante
Esto es el codigo en html5 para el diseño de una APP para Restaurantes, donde habra una interfaz grafica muy interactiva
para el usuario o cliente, el cual podra ver detalladamente los ingredientes de cada plato. Ademas podra visualizar el
plato en 3D, ver el precio, las calorias y el tiempo que tarda en llegar a tu mesa.

Esta APP sera contruida con Phonegap, el cual nos creara el APK para nuestros dispositivos Android.
